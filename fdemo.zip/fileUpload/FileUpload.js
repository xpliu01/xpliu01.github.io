
angular.module("FileUpload",['angularFileUpload']).directive('fileUpload',["$compile","FileUploader",function($compile,FileUploader){
    return {
        scope:{
            isShow:'=',//show file upload
            uploadOption:'='//file upload config
        },
        restrict: 'E',
        templateUrl: '/scripts/template/fileUpload.html',
        replace: true,
        link: function($scope, element) {
            $scope.$watch('uploadOption.uploadUrl',function() {
                if ($scope.uploadOption == undefined || $scope.uploadOption == null || $scope.uploadOption.uploadUrl == null
                    || $scope.uploadOption.uploadUrl == undefined || $scope.uploadOption.uploadUrl == "") {
                    return;
                }
                var option = $scope.uploadOption;
                $scope.selectItems = [];

                var uploader = $scope.uploader = new FileUploader({
                    url: option.uploadUrl
                    //formData:{Basket1:'quality1'}
                });

                // FILTERS
                /*uploader.filters.push({
                 name: 'customFilter',
                 fn: function(item, options) {
                 return this.queue.length < 10;
                 }
                 });
                 // CALLBACKS
                 uploader.onWhenAddingFileFailed = function(item, filter, options) {
                 //console.info('onWhenAddingFileFailed', item, filter, options);
                 if($scope.onWhenAddingFileFailed != undefined){
                 $scope.onWhenAddingFileFailed(item, filter, options); //{File|FileLikeObject}
                 }
                 };
                 uploader.onAfterAddingFile = function(fileItem) {
                 //console.info('onAfterAddingFile', fileItem);
                 if($scope.onAfterAddingFile != undefined){
                 $scope.onAfterAddingFile(fileItem);
                 }
                 };
                 uploader.onAfterAddingAll = function(addedFileItems) {
                 //console.info('onAfterAddingAll', addedFileItems);
                 if($scope.onAfterAddingAll != undefined){
                 $scope.onAfterAddingAll(addedFileItems);
                 }
                 };
                 uploader.onBeforeUploadItem = function(item) {//{File|FileLikeObject}
                 //console.info('onBeforeUploadItem', item);
                 if($scope.onBeforeUploadItem != undefined){
                 $scope.onBeforeUploadItem(item);
                 }
                 };
                 uploader.onProgressItem = function(fileItem, progress) {
                 //console.info('onProgressItem', fileItem, progress);
                 if($scope.onProgressItem != undefined){
                 $scope.onProgressItem(fileItem, progress);
                 }
                 };
                 uploader.onProgressAll = function(progress) {
                 //console.info('onProgressAll', progress);
                 if($scope.onProgressAll != undefined){
                 $scope.onProgressAll(progress);
                 }
                 };
                 uploader.onErrorItem = function(fileItem, response, status, headers) {
                 if($scope.onErrorItem != undefined){
                 $scope.onErrorItem(fileItem, response, status, headers);
                 }else{
                 console.info('onErrorItem', fileItem, response, status, headers);
                 }
                 };
                 uploader.onCancelItem = function(fileItem, response, status, headers) {
                 if($scope.onCancelItem != undefined){
                 $scope.onCancelItem(fileItem, response, status, headers);
                 }else{
                 console.info('onCancelItem', fileItem, response, status, headers);
                 }
                 };
                 uploader.onCompleteItem = function(fileItem, response, status, headers) {
                 if($scope.onCompleteItem != undefined){
                 $scope.onCompleteItem(fileItem, response, status, headers);
                 }else{
                 console.info('onCompleteItem', fileItem, response, status, headers);
                 }
                 };
                 uploader.onCompleteAll = function() {
                 if($scope.onCompleteAll != undefined){
                 $scope.onCompleteAll();
                 }else{
                 console.info('onCompleteAll');
                 }
                 };
                 uploader.onAfterAddingFile = function(fileItem) {
                 console.info('onAfterAddingFile', fileItem);
                 console.info('onAfterAddingFile1', fileItem.formData);
                 console.info('onAfterAddingFile2', fileItem.file);
                 };
                 uploader.onBeforeUploadItem = function(item) {//{File|FileLikeObject}
                 console.info('onBeforeUploadItem', item);
                 };*/

                /* 上传成功回调函数 */
                uploader.onSuccessItem = function(fileItem, response, status, headers) {
                    $scope.selectItems.push(response[0]);
                    //console.log(fileItem,response, status, headers);
                };

                /* 删除所有文件 */
                $scope.clearQueue = function(){
                    $scope.uploader.clearQueue();
                    $scope.uploader.queue = [];
                    $scope.selectItems = [];
                }
                /* 删除指定文件 */
                $scope.clearQueueByIndex = function(item,index){
                    item.remove();
                    //console.log(index);
                    $scope.selectItems.remove(index);
                }

                /* 关闭对话框 */
                $scope.closeFileUpDialog = function(){
                    angular.forEach($scope.uploader.queue,function(value,key){
                        if(!value.isUploaded){
                            $scope.uploader.queue[key].remove();
                        }
                    })
                    angular.forEach($scope.uploader.queue,function(value,key){
                        if(!value.isUploaded){
                            $scope.uploader.queue[key].remove();
                        }
                    })
                    $scope.submit();
                }
                /* 提交文件 */
                $scope.submitFiles = function(){
                    if(uploader.queue.length > $scope.selectItems.length){
                        alert("还有文件未上传！");
                        return;
                    }
                    $scope.submit();
                }

                /* 传递文件 */
                $scope.submit = function(){
                    $scope.isShow = false;
                    var items = angular.copy($scope.selectItems);
                    //$scope.uploader.clearQueue();
                    $scope.$emit("uploadFileItems",items);//传递已上传的文件信息到父控制器
                    //$scope.selectItems = [];
                }

                var uploadBtn = $("<input type='file' nv-file-select uploader='uploader' style='height: 25px;width:80px;font-size: 6px;position: absolute;opacity: 0;z-index: 100;cursor: pointer;' type='button' class='btn btn-default' />");
                if(option.multiple){
                    uploadBtn.attr("multiple","");
                }

                $compile(angular.element($("#_uploadSelect_").append(uploadBtn)))($scope);
            });
        }
    };
}]);