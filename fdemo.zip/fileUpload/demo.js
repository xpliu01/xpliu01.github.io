    
	 //<div><file-upload  upload-option="fileUploadOption" is-show="fileUpload" ></file-upload></div>
	$scope.fileUploadOption = {
        uploadUrl:'http://10.10.1.31:8076/api/FileUpload?Basket='+"quality",
        multiple:true,
        size:1
    }
    /* �����ϴ����ļ� */
    $scope.$on("uploadFileItems",function(event,data){
        //console.log(data);
        var fileStr = "";
        angular.forEach(data,function(data,key){
            fileStr += data.FileName + "��";
        });

        $scope.reimItem.attachment = fileStr;
     });
    $scope.uploadFile = function(){
        $scope.fileUpload = true;
    }